

module.exports.dashboard = (req,res)=>{
   
    res.render('dashboard/dashboard');
    //res.send('Hello World!');
}

