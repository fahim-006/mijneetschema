var Category = require("../../../models/Category");
var Product = require("../../../models/Products");
var Ingredients = require("../../../models/Ingredients");
var Meals = require("../../../models/Meals");
var MealCategory = require("../../../models/MealCategory");

const timestamp = require("time-stamp");
created_date = timestamp.utc("YYYY-MM-DD HH:mm:ss");
const { validationResult } = require("express-validator");
var randomstring = require("randomstring");
var md5 = require("md5");
const ejs = require("ejs");
//var Mail = require('../../../utilities/mail');
var fs = require("fs");
var path = require("path");






// ************** Create Plans *************** //


// ---------------  Get Plan --------------- //


module.exports.addPlan = (req, res) => {
    let id = req.session.user_data.user_id;
    if (typeof req.flash("formdata") == "undefined") {
      var formdata = { name: "", description: "", sku: "", price: "" };
      req.flash("formdata", formdata);
    }
    Ingredients.find({ added_by: id }, function (err, result) {
      if (err) {
        $message = { message: "Error occured" };
        req.flash("errors", $message);
      } else {
        if (result) {
          MealCategory.find({}, function (err, mealResult) {
            if (err) {
              $message = { message: "Error occured" };
              req.flash("errors", $message);
            } else {
              if (mealResult) {
                const foodSource = result.map((file) => file.source).filter((v, i, s) => s.indexOf(v) === i);
                const catData = mealResult.filter((item) => item.isDeleted !== true);
                console.log(result);
                res.render("plans/add-plan", {
                  formdata: req.flash("formdata"),
                  ingredientData: result,
                  baseUrl: 'localhost:4333',
                  categoryData: catData,
                  foodSource: foodSource,
                  errors: req.flash("errors"),
                  reset: req.flash("reset"),
                  success: req.flash("success"),
                });
              }
            }
          });
          // console.log(result);
          // res.render("meals/meal", {
          //   formdata: req.flash("formdata"),
          //   ingredientData: result,
          //   errors: req.flash("errors"),
          //   reset: req.flash("reset"),
          //   success: req.flash("success"),
          // });
        }
      }
    });
  };

module.exports.createPlans = async (req, res) => {
    let id = req.session.user_data.user_id;
    const {name, protien, carbs, fat, fiber, unit, quantity, calories, source} = req.body;
    // Validate request
  
    var formdata = { 
        
      source,
        name,
      protien,
      carbs,
      fat,
      fiber,
      unit,
      quantity,
      calories,
  
        //protien = req.body.protien
    };
    
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      let errorsData = { category: "" };
      if (errors.array().length > 0) {
        errors.array().forEach((value) => {
          errorsData[value.param] = value.msg;
        });
        req.flash("errors", errorsData);
        req.flash("formdata", formdata);
        return res.redirect("/meals/ingredient/add");
      }
    }
  
    if (!req.body) {
      return res.status(400).send({
        message: "Note content can not be empty",
      });
    }
  
    $where = { name: req.body.name, added_by: req.body.id };
    var ingredientExist = await Ingredients.findOne($where).exec();
    if (ingredientExist) {
      return res.json({
        status: 400,
        message: "Ingredient already exit",
      });
    }
  
    // Create a category
    const ingredient = new Ingredients({
      source,
      name,
      protien,
      carbs,
      fat,
      fiber,
      unit,
      quantity,
      calories,
      added_by: id,
      created_at: created_date,
      updated_at: created_date,
    });
  
  
      try{
          await ingredient.save();
          $message = { msg: "Ingredients added successfully" };
            req.flash("errors", $message);
            return res.redirect("/meals/ingredient/add");
      }catch(err){
          $errors = { message: "Something went wrong!" };
            req.flash("errors", $errors);
            req.flash("formdata", formdata);
            return res.redirect("/meals/ingredient/add");
      }
  };
  